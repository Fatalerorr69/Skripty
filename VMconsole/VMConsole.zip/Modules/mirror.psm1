function Start-Mirror { param($Source, $Dest) robocopy $Source $Dest /MIR }
