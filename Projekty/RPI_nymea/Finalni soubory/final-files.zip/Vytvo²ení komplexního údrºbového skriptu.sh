# Stažení údržbového skriptu
wget -O /tmp/maintenance-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/maintenance-setup.sh
chmod +x /tmp/maintenance-setup.sh
sudo /tmp/maintenance-setup.sh