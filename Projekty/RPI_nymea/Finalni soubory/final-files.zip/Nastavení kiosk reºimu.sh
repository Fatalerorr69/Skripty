# Úprava konfigurace kiosk režimu
sudo nano /etc/default/nymea-kiosk

# Možné úpravy:
# - Nastavení výchozí URL
# - Konfigurace automatického přihlašování
# - Nastavení časovače pro automatické obnovení