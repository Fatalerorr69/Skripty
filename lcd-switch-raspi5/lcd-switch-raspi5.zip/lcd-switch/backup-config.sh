#!/bin/bash
echo "Zálohuji výchozí konfigurace..."
sudo cp /boot/config.txt /boot/config.txt.bak
sudo cp /boot/cmdline.txt /boot/cmdline.txt.bak
echo "Hotovo."
