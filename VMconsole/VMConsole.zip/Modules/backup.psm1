function Backup-VM { 
    param($VMName, $Dest)
    $file = Join-Path $Dest "$VMName-$((Get-Date).ToString('yyyyMMdd_HHmmss')).ova"
    & $Global:Config.VBoxManagePath export $VMName --output $file
    Write-Log "Záloha vytvořena: $file"
    Rotate-Backups -Dest $Dest
}
function Rotate-Backups {
    param($Dest)
    $files = Get-ChildItem -Path $Dest -Filter *.ova | Sort-Object LastWriteTime -Descending
    if ($files.Count -gt $Global:Config.BackupRetention) {
        $toRemove = $files[$Global:Config.BackupRetention..($files.Count - 1)]
        foreach ($f in $toRemove) {
            Remove-Item $f.FullName -Force
            Write-Log "Smazána stará záloha: $($f.Name)"
        }
    }
}
