param($VMName, $Action)
Import-Module "$PSScriptRoot\..\Modules\vbox.psm1" -Force
switch ($Action) {
    "start" { Start-VM -Name $VMName }
    "stop"  { & $Global:Config.VBoxManagePath controlvm $VMName poweroff }
}
