function Get-VMList { & $Global:Config.VBoxManagePath list vms }
function Start-VM { param($Name, $Type = $Global:Config.DefaultVMType) & $Global:Config.VBoxManagePath startvm $Name --type $Type }
