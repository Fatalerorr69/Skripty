Import-Module "$PSScriptRoot\..\Modules\logging.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\vbox.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\network.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\scheduler.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\monitor.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\backup.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\mirror.psm1" -Force
Import-Module "$PSScriptRoot\..\Modules\profiles.psm1" -Force
# GUI logika WPF by přišla sem
