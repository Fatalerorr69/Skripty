function Schedule-VMAction {
    param($VMName, $Action, $Time)
    schtasks /create /tn "VM_$Action`_$VMName" /tr "powershell -File `"$PSScriptRoot\..\Scripts\VMAction.ps1`" $VMName $Action" /sc once /st $Time
}
