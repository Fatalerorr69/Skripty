#!/bin/bash
LOG="/recalbox/share/system/logs/reset-es.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Reset EmulationStation ==="
rm -rf /recalbox/share/system/.emulationstation/cache/*
systemctl restart emulationstation
echo "Log uložen do $LOG"