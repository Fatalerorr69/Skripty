#!/bin/bash
LOG="/recalbox/share/system/logs/wifi.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Správa WiFi/LAN ==="
connmanctl