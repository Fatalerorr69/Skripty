#!/bin/bash
LOG="/recalbox/share/system/logs/restore.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Obnova konfigurace ==="
cp /recalbox/share/system/backup/*.conf /recalbox/share/system/
echo "Konfigurace obnovena"
echo "Log uložen do $LOG"