# Stažení a spuštění inicializačního skriptu
wget -O /tmp/init-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/init-setup.sh
chmod +x /tmp/init-setup.sh
sudo /tmp/init-setup.sh