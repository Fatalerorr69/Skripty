#!/bin/bash
LOG="/recalbox/share/system/logs/hardware.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Diagnostika hardwaru ==="
echo "CPU info:"
cat /proc/cpuinfo
echo
echo "RAM:"
free -h
echo
echo "Teplota:"
vcgencmd measure_temp
echo
echo "Využití disku:"
df -h
echo "Log uložen do $LOG"