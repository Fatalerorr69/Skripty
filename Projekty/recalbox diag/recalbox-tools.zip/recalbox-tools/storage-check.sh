#!/bin/bash
LOG="/recalbox/share/system/logs/storage.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Kontrola úložiště ==="
df -h
echo "Kontrola souborového systému..."
for disk in /dev/mmcblk0p1 /dev/sda1; do
  if [[ -b "$disk" ]]; then
    echo "Kontrola $disk"
    fsck -y $disk
  fi
done
echo "Oprava oprávnění..."
chown -R root:root /recalbox
chmod -R 755 /recalbox
echo "Log uložen do $LOG"