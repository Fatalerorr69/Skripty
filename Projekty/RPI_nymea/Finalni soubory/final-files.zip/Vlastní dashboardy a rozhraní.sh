# Instalace Node-RED pro vlastní dashboardy
bash <(curl -Ss https://raw.githubusercontent.com/node-red/linux-installers/master/deb/update-nodejs-and-nodered)

# Spuštění Node-RED
node-red-start