# Úprava konfigurace
nano /home/education-system/config/system-config.yaml

# Nastavení sítě
nano /home/education-system/config/network-config.yaml