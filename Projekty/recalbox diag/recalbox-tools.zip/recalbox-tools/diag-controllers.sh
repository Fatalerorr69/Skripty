#!/bin/bash
LOG="/recalbox/share/system/logs/controllers.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Diagnostika ovladačů ==="
lsusb
bluetoothctl devices
echo "Test tlačítek: evtest (vyber zařízení)"