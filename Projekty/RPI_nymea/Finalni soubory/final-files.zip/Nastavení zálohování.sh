# Vytvoření zálohovacího skriptu
sudo nano /usr/local/bin/nymea-backup.sh