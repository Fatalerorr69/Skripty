#!/bin/bash
LOG="/recalbox/share/system/logs/backup.log"
exec > >(tee -a "$LOG") 2>&1

BACKUP_DIR="/recalbox/share/backups"
mkdir -p $BACKUP_DIR

DATE=$(date +%Y%m%d_%H%M)
echo "=== Záloha Recalboxu ==="
tar czf "$BACKUP_DIR/recalbox_backup_$DATE.tar.gz" /recalbox/share/roms /recalbox/share/system/*.conf
echo "Hotovo, soubor: $BACKUP_DIR/recalbox_backup_$DATE.tar.gz"
echo "Log uložen do $LOG"