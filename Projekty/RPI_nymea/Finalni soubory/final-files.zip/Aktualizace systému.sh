# Aktualizace seznamu balíčků
sudo apt-get update

# Upgrade instalovaných balíčků
sudo apt-get upgrade -y

# Odstranění nepotřebných balíčků
sudo apt-get autoremove -y