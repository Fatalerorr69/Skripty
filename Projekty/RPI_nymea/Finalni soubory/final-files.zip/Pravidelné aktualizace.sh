# Nastavení automatických aktualizací
sudo apt-get install -y unattended-upgrades
sudo dpkg-reconfigure unattended-upgrades