# Instalace notifikačních pluginů
sudo apt-get install -y \
    nymea-plugin-pushnotification \
    nymea-plugin-mail \
    nymea-plugin-telegram