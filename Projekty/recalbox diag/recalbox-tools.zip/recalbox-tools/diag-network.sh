#!/bin/bash
# Diagnostika a oprava sítě
LOG="/recalbox/share/system/logs/network.log"
exec > >(tee -a "$LOG") 2>&1

# NASTAVENÍ WiFi
# Pokud je síť bez hesla, ponechej WIFI_PASS prázdné
WIFI_SSID="Tenda"
WIFI_PASS=""

echo "=== Diagnostika sítě ==="
ip a
ip route
cat /etc/resolv.conf
echo "Ping router..."
ping -c 4 192.168.1.1 || echo "Router nedostupný"
echo "Ping Internet..."
ping -c 4 8.8.8.8 || echo "Internet nedostupný"

# LAN priorita
ETH_STATUS=$(cat /sys/class/net/eth0/carrier 2>/dev/null || echo 0)
if [[ "$ETH_STATUS" == "1" ]]; then
  echo "Ethernet OK, nastavujeme DHCP..."
  dhclient -r eth0
  dhclient eth0
else
  echo "Ethernet ne, zkusíme WiFi $WIFI_SSID"
  connmanctl enable wifi
  connmanctl scan wifi
  WIFI_SERVICE=$(connmanctl services | grep "$WIFI_SSID" | awk '{print $3}')
  if [[ -n "$WIFI_SERVICE" ]]; then
    connmanctl agent on
    (echo "connect $WIFI_SERVICE"; sleep 2; echo "quit") | connmanctl
  else
    echo "Síť nenalezena"
  fi
fi

ping -c 4 8.8.8.8 || echo "Internet stále nedostupný"
echo "Log uložen do $LOG"