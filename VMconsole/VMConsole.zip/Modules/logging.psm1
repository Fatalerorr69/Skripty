function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logDir = "$PSScriptRoot\..\logs"
    if (-not (Test-Path $logDir)) { New-Item -Path $logDir -ItemType Directory | Out-Null }
    "$timestamp [$Level] $Message" | Out-File "$logDir\app.log" -Append -Encoding utf8
}
