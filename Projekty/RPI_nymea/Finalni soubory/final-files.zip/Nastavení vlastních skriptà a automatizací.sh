# Vytvoření adresáře pro vlastní skripty
mkdir ~/scripts

# Ukázkový skript pro zálohování
nano ~/scripts/backup-system.sh