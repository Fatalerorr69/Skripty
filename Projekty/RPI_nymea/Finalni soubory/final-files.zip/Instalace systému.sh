# Spuštění instalačního skriptu
cd /home/education-system/bin
sudo ./system-setup.sh --role=teacher --project-focus=iot

# Nebo pro studenty
sudo ./system-setup.sh --role=student --username=student01