function Set-VMNetwork { param($VMName, $Adapter, $Mode) & $Global:Config.VBoxManagePath modifyvm $VMName --nic$Adapter $Mode }
