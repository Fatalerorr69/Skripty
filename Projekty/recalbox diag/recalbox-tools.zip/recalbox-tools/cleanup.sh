#!/bin/bash
LOG="/recalbox/share/system/logs/cleanup.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Čištění systému ==="
rm -rf /recalbox/share/system/tmp/*
rm -rf /recalbox/share/system/logs/*.old
echo "Hotovo"