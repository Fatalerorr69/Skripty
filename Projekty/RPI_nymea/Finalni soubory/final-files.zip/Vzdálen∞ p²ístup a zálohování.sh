# Nastavení SSH klíčů pro bezpečnější přístup
ssh-copy-id nymea@ip-adresa-raspberry-pi

# Vytvoření zálohy konfigurace nymea
sudo nymeadctl --backup ~/nymea-backup.tar.gz