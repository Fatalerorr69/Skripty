# Spuštění síťového konfiguračního skriptu
wget -O /tmp/network-setup.sh https://raw.githubusercontent.com/example/nymea-init/main/network-setup.sh
chmod +x /tmp/network-setup.sh
sudo /tmp/network-setup.sh