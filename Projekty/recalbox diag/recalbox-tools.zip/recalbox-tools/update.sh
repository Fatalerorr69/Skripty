#!/bin/bash
LOG="/recalbox/share/system/logs/update.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Aktualizace systému ==="
recalbox-upgrade
echo "Log uložen do $LOG"