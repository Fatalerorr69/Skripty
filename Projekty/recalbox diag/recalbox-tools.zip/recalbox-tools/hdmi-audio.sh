#!/bin/bash
LOG="/recalbox/share/system/logs/hdmi-audio.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Detekce HDMI / Audio ==="
tvservice -s
amixer