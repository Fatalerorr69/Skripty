#!/bin/bash
# Recalbox Swiss Army Knife - hlavní menu

TOOLS_DIR="$(dirname "$0")"

while true; do
  clear
  echo "=== Recalbox Tools ==="
  echo "1) Diagnostika sítě"
  echo "2) Diagnostika hardwaru"
  echo "3) Kontrola a oprava úložiště"
  echo "4) Zálohování"
  echo "5) Aktualizace systému"
  echo "6) Obnova konfigurace"
  echo "7) Správa WiFi/LAN"
  echo "8) Diagnostika ovladačů"
  echo "9) Reset EmulationStation"
  echo "10) Čistič systému"
  echo "11) HDMI/Audio tester"
  echo "0) Konec"
  echo -n "Vyber akci: "
  read choice

  case $choice in
    1)  bash "$TOOLS_DIR/diag-network.sh" ;;
    2)  bash "$TOOLS_DIR/diag-hardware.sh" ;;
    3)  bash "$TOOLS_DIR/storage-check.sh" ;;
    4)  bash "$TOOLS_DIR/backup.sh" ;;
    5)  bash "$TOOLS_DIR/update.sh" ;;
    6)  bash "$TOOLS_DIR/restore-config.sh" ;;
    7)  bash "$TOOLS_DIR/wifi-manager.sh" ;;
    8)  bash "$TOOLS_DIR/diag-controllers.sh" ;;
    9)  bash "$TOOLS_DIR/reset-es.sh" ;;
    10) bash "$TOOLS_DIR/cleanup.sh" ;;
    11) bash "$TOOLS_DIR/hdmi-audio.sh" ;;
    0)  echo "Konec." ; exit 0 ;;
    *)  echo "Neplatná volba." ; sleep 2 ;;
  esac
done