function Get-VMStats { param($VMName) & $Global:Config.VBoxManagePath metrics collect $VMName }
