function Save-VMProfile {
    param($VMName, $CPU, $RAM, $GPU)
    $profilePath = Join-Path $Global:Config.ProfilesDir "$VMName.psd1"
    @{
      CPU = $CPU
      RAM = $RAM
      GPU = $GPU
    } | Export-Clixml -Path $profilePath
    Write-Log "Uložen profil pro VM: $VMName"
}
function Load-VMProfile {
    param($VMName)
    $profilePath = Join-Path $Global:Config.ProfilesDir "$VMName.psd1"
    if (Test-Path $profilePath) {
        $profile = Import-Clixml $profilePath
        & $Global:Config.VBoxManagePath modifyvm $VMName --cpus $profile.CPU --memory $profile.RAM
        Write-Log "Aplikován profil pro VM: $VMName"
    } else {
        Write-Log "Profil pro VM $VMName nenalezen" "WARN"
    }
}
