# Instalace kalibračních nástrojů
sudo apt-get install -y xinput-calibrator

# Spuštění kalibrace
xinput_calibrator