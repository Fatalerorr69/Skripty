# Editace konfigurace kiosku
sudo nano /etc/default/nymea-kiosk