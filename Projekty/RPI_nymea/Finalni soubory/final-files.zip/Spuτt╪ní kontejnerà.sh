# Build a spuštění Docker kontejnerů
cd /home/education-system
docker-compose up -d

# Kontrola stavu
docker-compose ps